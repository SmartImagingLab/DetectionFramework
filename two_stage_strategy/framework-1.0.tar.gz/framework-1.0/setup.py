# -*- coding: utf-8 -*-
# @Time : 2022/10/9 20:57
# @Author : lwb
# @File : setup.py


# coding:utf8
import setuptools
from setuptools import setup

setup(
    name='framework',  # 项目名
    version='1.0',  # 版本号
    author="Liuwenbo",
    author_email="wenbo_liu96@163.com",
    # packages=['framework'],
    # packages=setuptools.find_packages(),  # 包括在安装包内的Python包
    packages=setuptools.find_namespace_packages(),  # 包括在安装包内的Python包
    install_requires=[
        'requests',
        'importlib; python_version == "3.8"',
    ],
)
