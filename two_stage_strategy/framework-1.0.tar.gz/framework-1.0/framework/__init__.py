# -*- coding: utf-8 -*-
# @Time : 2022/10/10 12:59
# @Author : lwb
# @File : __init__.py

# !/usr/bin/env python
# -*- coding:utf-8 -*-

def test():
    print("This is a test code!")


if __name__ == '__main__':
    test()
